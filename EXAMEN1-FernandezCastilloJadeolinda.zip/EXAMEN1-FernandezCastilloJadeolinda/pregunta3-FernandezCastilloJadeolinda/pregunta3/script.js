function calcular(){
    const radios = document.getElementsByName("rdnTemp")
    const selected = Array.from(radios).find(radio => radio.checked).value
    
    const temp = document.getElementById("temperatura").value


    let ntemp = 0
    let chartemp
    if(selected == 'celsius'){
        ntemp = (parseInt(temp) - 32) * (5/9)
        chartemp = "C"
    }else{
        ntemp = (parseInt(temp) * (9/5)) + 32
        chartemp = "F"
    }

    ntemp = ntemp.toFixed(2)

    alert("La temperatura calculada es " + ntemp + " "+chartemp)
}
